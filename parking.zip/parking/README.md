## Parking

Run the following command

- composer require tymon/jwt-auth
- php artisan jwt:secret
- npm install
- npm run dev
- composer update
